"""SQLite helpers. The database file is created automatically on first run."""
import sqlite3
from contextlib import closing
from datetime import datetime, timedelta
from pathlib import Path

import pandas as pd

import sample_data as sd

DB_PATH = Path(__file__).parent / "timetable.db"

SCHEMA = """
CREATE TABLE IF NOT EXISTS teachers (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT UNIQUE NOT NULL,
    available_days TEXT,
    available_periods TEXT,
    preferred_periods TEXT
);
CREATE TABLE IF NOT EXISTS rooms (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    room_no TEXT UNIQUE NOT NULL,
    room_type TEXT,
    capacity INTEGER
);
CREATE TABLE IF NOT EXISTS subjects (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    teacher TEXT,
    classes_per_week INTEGER,
    type TEXT,
    class_name TEXT,
    class_size INTEGER
);
CREATE TABLE IF NOT EXISTS timeslots (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    day TEXT,
    period INTEGER,
    start_time TEXT,
    end_time TEXT,
    active INTEGER DEFAULT 1
);
CREATE TABLE IF NOT EXISTS timetable (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    subject TEXT,
    class_name TEXT,
    teacher TEXT,
    room TEXT,
    day TEXT,
    period INTEGER,
    subject_type TEXT,
    class_size INTEGER
);
CREATE TABLE IF NOT EXISTS notifications (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    created_at TEXT,
    kind TEXT,
    subject TEXT,
    old_slot TEXT,
    new_slot TEXT,
    reason TEXT,
    emailed INTEGER DEFAULT 0
);
CREATE TABLE IF NOT EXISTS settings (
    key TEXT PRIMARY KEY,
    value TEXT
);
"""

DEFAULT_SETTINGS = {
    "prevent_teacher_clash": True,   # hard
    "prevent_room_clash": True,      # hard
    "require_lab_room": True,        # hard
    "respect_availability": True,    # hard
    "avoid_back_to_back": True,      # soft
    "limit_workload": True,          # soft
    "max_periods_per_day": 4,        # used by "limit_workload"
}


# ---------------------------------------------------------------- basics
def connect():
    return sqlite3.connect(DB_PATH)


def execute(query, params=()):
    with closing(connect()) as conn:
        cur = conn.execute(query, params)
        conn.commit()
        return cur.lastrowid


def read_df(query_or_table, params=()):
    """Read a whole table (pass its name) or run a SELECT query."""
    query = query_or_table
    if " " not in query.strip():
        query = f"SELECT * FROM {query}"
    with closing(connect()) as conn:
        return pd.read_sql_query(query, conn, params=params)


def save_table(table, df):
    """Replace the whole table with the rows of `df` (id column is regenerated)."""
    df = df.drop(columns=["id"], errors="ignore")
    with closing(connect()) as conn:
        try:
            conn.execute(f"DELETE FROM {table}")
            if len(df):
                df.to_sql(table, conn, if_exists="append", index=False)
            conn.commit()
        except Exception:
            conn.rollback()
            raise


# ---------------------------------------------------------------- setup
def default_timeslots(days=None, periods=sd.PERIODS_PER_DAY, start="09:00", length=50, gap=10):
    """Build a list of (day, period, start, end) rows."""
    days = days or sd.DAYS
    rows = []
    for day in days:
        for p in range(1, periods + 1):
            if periods == sd.PERIODS_PER_DAY and start == "09:00" and length == 50 and gap == 10:
                s, e = sd.DEFAULT_PERIOD_TIMES[p - 1]
            else:
                t0 = datetime.strptime(start, "%H:%M") + timedelta(minutes=(p - 1) * (length + gap))
                s, e = t0.strftime("%H:%M"), (t0 + timedelta(minutes=length)).strftime("%H:%M")
            rows.append((day, p, s, e))
    return rows


def reset_timeslots(rows=None):
    rows = rows or default_timeslots()
    df = pd.DataFrame(rows, columns=["day", "period", "start_time", "end_time"])
    df["active"] = 1
    save_table("timeslots", df)


def init_db():
    """Create tables and load sample data when the database is empty."""
    with closing(connect()) as conn:
        conn.executescript(SCHEMA)
        conn.commit()
        if conn.execute("SELECT COUNT(*) FROM teachers").fetchone()[0] == 0:
            conn.executemany(
                "INSERT INTO teachers (name, available_days, available_periods, preferred_periods) VALUES (?,?,?,?)",
                sd.SAMPLE_TEACHERS)
            conn.executemany("INSERT INTO rooms (room_no, room_type, capacity) VALUES (?,?,?)", sd.SAMPLE_ROOMS)
            conn.executemany(
                "INSERT INTO subjects (name, teacher, classes_per_week, type, class_name, class_size) VALUES (?,?,?,?,?,?)",
                sd.SAMPLE_SUBJECTS)
            conn.commit()
        if conn.execute("SELECT COUNT(*) FROM timeslots").fetchone()[0] == 0:
            conn.executemany(
                "INSERT INTO timeslots (day, period, start_time, end_time, active) VALUES (?,?,?,?,1)",
                default_timeslots())
            conn.commit()


def reset_sample_data():
    """Wipe everything and reload the sample data."""
    with closing(connect()) as conn:
        for t in ["teachers", "rooms", "subjects", "timeslots", "timetable", "notifications", "settings"]:
            conn.execute(f"DELETE FROM {t}")
        conn.commit()
    init_db()


# ---------------------------------------------------------------- settings
def get_settings():
    settings = dict(DEFAULT_SETTINGS)
    with closing(connect()) as conn:
        for key, value in conn.execute("SELECT key, value FROM settings"):
            if key in settings:
                default = DEFAULT_SETTINGS[key]
                settings[key] = int(value) if isinstance(default, int) and not isinstance(default, bool) \
                    else value == "1"
    return settings


def save_settings(settings):
    with closing(connect()) as conn:
        for key, value in settings.items():
            conn.execute("INSERT OR REPLACE INTO settings (key, value) VALUES (?, ?)",
                         (key, str(int(value))))
        conn.commit()


# ---------------------------------------------------------------- timetable
def replace_timetable(rows):
    """rows: list of dicts with subject, class_name, teacher, room, day, period, subject_type, class_size."""
    cols = ["subject", "class_name", "teacher", "room", "day", "period", "subject_type", "class_size"]
    save_table("timetable", pd.DataFrame(rows, columns=cols))


def update_timetable_entry(entry_id, room, day, period):
    execute("UPDATE timetable SET room=?, day=?, period=? WHERE id=?",
            (room, day, int(period), int(entry_id)))
