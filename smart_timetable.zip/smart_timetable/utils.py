"""Small helper functions shared by the other modules."""
import sample_data as sd


def parse_days(text):
    """'Monday, Tuesday' -> ['Monday', 'Tuesday'] (empty text means every day)."""
    if text is None or str(text).strip() == "":
        return list(sd.ALL_WEEKDAYS)
    wanted = {d.strip().lower() for d in str(text).split(",") if d.strip()}
    return [d for d in sd.ALL_WEEKDAYS if d.lower() in wanted]


def parse_periods(text, default=None):
    """'1, 2,3' -> [1, 2, 3] (empty text -> default / every period)."""
    if text is None or str(text).strip() == "":
        return list(default) if default is not None else None
    result = []
    for part in str(text).split(","):
        part = part.strip()
        if part.isdigit():
            result.append(int(part))
    return result


def teacher_info(teachers_df):
    """Return {teacher_name: {'days': set or None, 'periods': set or None, 'preferred': set}}.
    None means 'no restriction'."""
    info = {}
    for _, t in teachers_df.iterrows():
        days = str(t.get("available_days") or "").strip()
        periods = str(t.get("available_periods") or "").strip()
        info[t["name"]] = {
            "days": set(parse_days(days)) if days else None,
            "periods": set(parse_periods(periods)) if periods else None,
            "preferred": set(parse_periods(t.get("preferred_periods"), default=[]) or []),
        }
    return info


def is_available(info, teacher, day, period):
    t = info.get(teacher)
    if t is None:
        return True
    if t["days"] is not None and day not in t["days"]:
        return False
    if t["periods"] is not None and period not in t["periods"]:
        return False
    return True


def slot_text(day, period):
    return f"{day} - Period {int(period)}"


def count_word(n):
    return {2: "two", 3: "three", 4: "four"}.get(n, str(n))
