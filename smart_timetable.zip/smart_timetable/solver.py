"""Timetable generation with OR-Tools CP-SAT.

Decision variable:  y[s, d, p, r] = 1  ->  subject s is taught on day d, period p, in room r.
Hard rules are written as constraints, soft rules are added to the objective as penalties.
"""
import math
from collections import defaultdict

from ortools.sat.python import cp_model

from utils import teacher_info, is_available


def _active_slots(slots_df):
    """List of (day, period) in the order they appear in the table."""
    df = slots_df[slots_df["active"] == 1]
    return [(r["day"], int(r["period"])) for _, r in df.iterrows()]


def _room_ok(subject, room, settings):
    """Can this subject use this room? (capacity is always checked)"""
    if room["capacity"] is not None and room["capacity"] < (subject["class_size"] or 0):
        return False
    if settings["require_lab_room"]:
        if subject["type"] == "Lab":
            return room["room_type"] == "Lab"
        return room["room_type"] == "Classroom"      # keep lab rooms free for lab subjects
    return True


def diagnose(subjects, teachers, rooms, slots, settings, tinfo):
    """Plain-English reasons why a timetable may be impossible."""
    msgs = []
    if not slots:
        return ["There are no active time slots. Add some on the 'Time Slots' page."]
    per_class, per_teacher = defaultdict(int), defaultdict(int)
    for s in subjects:
        per_class[s["class_name"]] += s["classes_per_week"]
        per_teacher[s["teacher"]] += s["classes_per_week"]
        if not any(_room_ok(s, r, settings) for r in rooms):
            msgs.append(f"No suitable room exists for '{s['name']}' ({s['class_name']}). "
                        f"Check room types and capacity (needs {s['class_size']} seats).")
    for c, n in per_class.items():
        if n > len(slots):
            msgs.append(f"Class {c} needs {n} periods per week but only {len(slots)} slots exist.")
    for t, n in per_teacher.items():
        free = [sl for sl in slots if not settings["respect_availability"] or is_available(tinfo, t, *sl)]
        if n > len(free):
            msgs.append(f"Teacher {t} must teach {n} periods but is only available for {len(free)} slots.")
    return msgs


def generate_timetable(subjects_df, teachers_df, rooms_df, slots_df, settings, time_limit=20):
    """Returns (ok, rows, messages).  rows is a list of dicts ready for the timetable table."""
    subjects = subjects_df.to_dict("records")
    rooms = rooms_df.to_dict("records")
    slots = _active_slots(slots_df)
    tinfo = teacher_info(teachers_df)

    if not subjects or not rooms or not slots:
        return False, [], ["Please add subjects, rooms and active time slots first."]

    problems = diagnose(subjects, teachers_df, rooms, slots, settings, tinfo)
    if problems:
        return False, [], problems

    days = list(dict.fromkeys(d for d, _ in slots))
    slot_set = set(slots)
    model = cp_model.CpModel()

    # ---- variables: only create the ones that are allowed (this already enforces several rules)
    y = {}
    for si, s in enumerate(subjects):
        for (d, p) in slots:
            if settings["respect_availability"] and not is_available(tinfo, s["teacher"], d, p):
                continue
            for ri, r in enumerate(rooms):
                if _room_ok(s, r, settings):
                    y[si, d, p, ri] = model.NewBoolVar(f"y_{si}_{d}_{p}_{ri}")

    by_subject = defaultdict(list)
    by_subject_day = defaultdict(list)
    by_slot_room = defaultdict(list)
    by_teacher_slot = defaultdict(list)
    by_class_slot = defaultdict(list)
    for (si, d, p, ri), var in y.items():
        s = subjects[si]
        by_subject[si].append(var)
        by_subject_day[si, d].append(var)
        by_slot_room[d, p, ri].append(var)
        by_teacher_slot[s["teacher"], d, p].append(var)
        by_class_slot[s["class_name"], d, p].append(var)

    # ---- every subject gets exactly its number of classes per week
    for si, s in enumerate(subjects):
        model.Add(sum(by_subject[si]) == int(s["classes_per_week"]))

        # spread classes over the week (at most N per day)
        usable_days = [d for d in days
                       if not settings["respect_availability"]
                       or any(is_available(tinfo, s["teacher"], d, p) for (dd, p) in slots if dd == d)]
        per_day = math.ceil(int(s["classes_per_week"]) / max(1, len(usable_days)))
        for d in days:
            if by_subject_day[si, d]:
                model.Add(sum(by_subject_day[si, d]) <= per_day)

    # ---- HARD: a class can only have one subject at a time (always on)
    for key, vars_ in by_class_slot.items():
        model.Add(sum(vars_) <= 1)

    # ---- HARD: room double booking
    if settings["prevent_room_clash"]:
        for vars_ in by_slot_room.values():
            model.Add(sum(vars_) <= 1)

    # ---- HARD: teacher double booking
    if settings["prevent_teacher_clash"]:
        for vars_ in by_teacher_slot.values():
            model.Add(sum(vars_) <= 1)

    # ---- SOFT rules ---------------------------------------------------------------
    penalties = []

    # busy[t, d, p] = 1 when teacher t teaches during that slot
    busy = {}
    if settings["avoid_back_to_back"] or settings["limit_workload"]:
        for (t, d, p), vars_ in by_teacher_slot.items():
            b = model.NewBoolVar(f"busy_{t}_{d}_{p}")
            model.Add(sum(vars_) >= 1).OnlyEnforceIf(b)
            model.Add(sum(vars_) == 0).OnlyEnforceIf(b.Not())
            busy[t, d, p] = b

    if settings["avoid_back_to_back"]:
        for (t, d, p), b1 in busy.items():
            b2 = busy.get((t, d, p + 1))
            if b2 is not None and (d, p + 1) in slot_set:
                bb = model.NewBoolVar(f"bb_{t}_{d}_{p}")
                model.Add(bb >= b1 + b2 - 1)
                penalties.append(3 * bb)

    if settings["limit_workload"]:
        limit = int(settings["max_periods_per_day"])
        teachers_in_use = {t for (t, _, _) in busy}
        for t in teachers_in_use:
            for d in days:
                day_busy = [b for (tt, dd, _), b in busy.items() if tt == t and dd == d]
                if len(day_busy) > limit:
                    over = model.NewIntVar(0, len(day_busy), f"over_{t}_{d}")
                    model.Add(over >= sum(day_busy) - limit)
                    penalties.append(10 * over)

    # Teacher preferred periods give a small reward (always on)
    rewards = []
    for (si, d, p, ri), var in y.items():
        pref = tinfo.get(subjects[si]["teacher"], {}).get("preferred", set())
        if p in pref:
            rewards.append(var)

    if penalties or rewards:
        model.Minimize(sum(penalties) - sum(rewards))

    # ---- solve ---------------------------------------------------------------------
    solver = cp_model.CpSolver()
    solver.parameters.max_time_in_seconds = float(time_limit)
    try:
        solver.parameters.num_workers = 4
    except Exception:           # older OR-Tools versions
        solver.parameters.num_search_workers = 4
    status = solver.Solve(model)

    if status in (cp_model.OPTIMAL, cp_model.FEASIBLE):
        rows = []
        for (si, d, p, ri), var in y.items():
            if solver.Value(var):
                s = subjects[si]
                rows.append({
                    "subject": s["name"], "class_name": s["class_name"], "teacher": s["teacher"],
                    "room": rooms[ri]["room_no"], "day": d, "period": p,
                    "subject_type": s["type"], "class_size": int(s["class_size"] or 0),
                })
        day_order = {d: i for i, d in enumerate(days)}
        rows.sort(key=lambda r: (day_order[r["day"]], r["period"], r["class_name"]))
        label = "an optimal" if status == cp_model.OPTIMAL else "a good (time limit reached)"
        return True, rows, [f"Solver found {label} timetable with {len(rows)} classes."]

    if status == cp_model.INFEASIBLE:
        return False, [], [
            "No timetable satisfies all the hard constraints.",
            "Try: more rooms/time slots, wider teacher availability, fewer classes per week, "
            "or untick a hard constraint on the 'Constraints' page.",
        ]
    return False, [], ["The solver ran out of time. Increase the time limit and try again."]
