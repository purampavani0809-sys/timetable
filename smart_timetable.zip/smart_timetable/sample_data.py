"""Sample data used to fill the database the first time the app starts."""

DAYS = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday"]
ALL_WEEKDAYS = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"]
PERIODS_PER_DAY = 6

# Default period timings (start, end)
DEFAULT_PERIOD_TIMES = [
    ("09:00", "09:50"),
    ("10:00", "10:50"),
    ("11:00", "11:50"),
    ("12:00", "12:50"),
    ("14:00", "14:50"),
    ("15:00", "15:50"),
]

ALL_DAYS_TEXT = ",".join(DAYS)
ALL_PERIODS_TEXT = ",".join(str(p) for p in range(1, PERIODS_PER_DAY + 1))

# (name, available_days, available_periods, preferred_periods)
SAMPLE_TEACHERS = [
    ("Ravi",   ALL_DAYS_TEXT,                       "1,2,3,4,5",   "1,2"),
    ("Priya",  "Monday,Tuesday,Wednesday,Thursday", ALL_PERIODS_TEXT, "2,3"),
    ("Anil",   ALL_DAYS_TEXT,                       "2,3,4,5,6",   "3,4"),
    ("Sneha",  ALL_DAYS_TEXT,                       ALL_PERIODS_TEXT, "1,2"),
    ("Kiran",  ALL_DAYS_TEXT,                       ALL_PERIODS_TEXT, "4,5"),
    ("Meena",  "Tuesday,Thursday",                  ALL_PERIODS_TEXT, "3,4"),
]

# (room_no, room_type, capacity)
SAMPLE_ROOMS = [
    ("101",   "Classroom", 60),
    ("102",   "Classroom", 60),
    ("103",   "Classroom", 45),
    ("Lab-1", "Lab",       40),
    ("Lab-2", "Lab",       40),
]

# (name, teacher, classes_per_week, type, class_name, class_size)
SAMPLE_SUBJECTS = [
    # Class CSE-A
    ("DBMS",               "Ravi",  4, "Theory", "CSE-A", 40),
    ("Operating Systems",  "Priya", 4, "Theory", "CSE-A", 40),
    ("Computer Networks",  "Anil",  3, "Theory", "CSE-A", 40),
    ("Mathematics",        "Sneha", 3, "Theory", "CSE-A", 40),
    ("DBMS Lab",           "Ravi",  2, "Lab",    "CSE-A", 40),
    ("Python Lab",         "Kiran", 2, "Lab",    "CSE-A", 40),
    # Class CSE-B
    ("DBMS",               "Ravi",  3, "Theory", "CSE-B", 35),
    ("Operating Systems",  "Priya", 3, "Theory", "CSE-B", 35),
    ("Computer Networks",  "Anil",  3, "Theory", "CSE-B", 35),
    ("Mathematics",        "Sneha", 3, "Theory", "CSE-B", 35),
    ("Python Lab",         "Kiran", 2, "Lab",    "CSE-B", 35),
    ("Networks Lab",       "Meena", 2, "Lab",    "CSE-B", 35),
]
