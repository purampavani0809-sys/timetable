"""Conflict detection and automatic conflict resolution (no solver needed here)."""
import pandas as pd

from utils import teacher_info, is_available, slot_text, count_word

TYPE_REASON = {
    "Teacher": "Teacher double booking",
    "Room": "Room double booking",
    "Class": "Class clash (two subjects at once)",
    "Lab": "Lab subject in a normal classroom",
    "Availability": "Teacher availability conflict",
    "Capacity": "Room too small for the class",
}


def detect_conflicts(tt, teachers_df, rooms_df):
    """Return a list of conflicts. Each one is a dict: type, message, ids (timetable rows involved)."""
    conflicts = []
    if tt.empty:
        return conflicts
    tinfo = teacher_info(teachers_df)
    rooms = {r["room_no"]: r for _, r in rooms_df.iterrows()}

    def group_conflicts(col, kind, text):
        for (name, day, period), g in tt.groupby([col, "day", "period"]):
            if len(g) > 1:
                conflicts.append({
                    "type": kind,
                    "message": text(name, day, period, g),
                    "ids": sorted(int(i) for i in g["id"]),
                })

    group_conflicts("teacher", "Teacher", lambda n, d, p, g:
                    f"Teacher {n} is assigned to {count_word(len(g))} classes at {d} Period {p}.")
    group_conflicts("room", "Room", lambda n, d, p, g:
                    f"Room {n} is booked for {count_word(len(g))} classes at {d} Period {p}.")
    group_conflicts("class_name", "Class", lambda n, d, p, g:
                    f"Class {n} has {count_word(len(g))} subjects ({', '.join(g['subject'])}) at {d} Period {p}.")

    for _, row in tt.iterrows():
        room = rooms.get(row["room"])
        if room is not None:
            if row["subject_type"] == "Lab" and room["room_type"] != "Lab":
                conflicts.append({
                    "type": "Lab", "ids": [int(row["id"])],
                    "message": f"Lab subject {row['subject']} ({row['class_name']}) is in classroom "
                               f"{row['room']} at {row['day']} Period {row['period']}."})
            if room["capacity"] and room["capacity"] < (row["class_size"] or 0):
                conflicts.append({
                    "type": "Capacity", "ids": [int(row["id"])],
                    "message": f"Room {row['room']} (capacity {room['capacity']}) is too small for "
                               f"{row['class_name']} ({row['class_size']} students) at "
                               f"{row['day']} Period {row['period']}."})
        if not is_available(tinfo, row["teacher"], row["day"], row["period"]):
            conflicts.append({
                "type": "Availability", "ids": [int(row["id"])],
                "message": f"Teacher {row['teacher']} is not available at {row['day']} Period {row['period']} "
                           f"but is assigned {row['subject']} ({row['class_name']})."})
    return conflicts


# ------------------------------------------------------------------ resolution
def _find_best_slot(entry, others, tinfo, rooms_df, slots):
    """Search all (day, period, room) options that break no rule; return (best, number_of_candidates)."""
    candidates = []
    teacher_busy = set(zip(others[others.teacher == entry["teacher"]].day,
                           others[others.teacher == entry["teacher"]].period))
    class_busy = set(zip(others[others.class_name == entry["class_name"]].day,
                         others[others.class_name == entry["class_name"]].period))
    room_busy = set(zip(others.room, others.day, others.period))
    same_subject_days = set(others[(others.subject == entry["subject"]) &
                                   (others.class_name == entry["class_name"])].day)
    preferred = tinfo.get(entry["teacher"], {}).get("preferred", set())

    for (day, period) in slots:
        if not is_available(tinfo, entry["teacher"], day, period):
            continue
        if (day, period) in teacher_busy or (day, period) in class_busy:
            continue
        for _, room in rooms_df.iterrows():
            if (room["room_no"], day, period) in room_busy:
                continue
            if entry["subject_type"] == "Lab" and room["room_type"] != "Lab":
                continue
            if entry["subject_type"] != "Lab" and room["room_type"] == "Lab":
                continue
            if room["capacity"] and room["capacity"] < (entry["class_size"] or 0):
                continue
            if day == entry["day"] and period == entry["period"] and room["room_no"] == entry["room"]:
                continue
            # lower score = better (small, less disruptive moves are preferred)
            score = 0.0
            score += 0 if day == entry["day"] else 2
            score += abs(period - entry["period"]) * 0.1
            score += 20 if day in same_subject_days and day != entry["day"] else 0
            score += 0 if (not preferred or period in preferred) else 1
            score += 0 if room["room_no"] == entry["room"] else 0.5
            if (entry["teacher"] and ((day, period - 1) in teacher_busy or (day, period + 1) in teacher_busy)):
                score += 2
            candidates.append((score, day, int(period), room["room_no"]))
    if not candidates:
        return None, 0
    candidates.sort()
    return candidates[0], len(candidates)


def resolve_conflicts(tt, teachers_df, rooms_df, slots_df, max_moves=50):
    """Try to fix every conflict by moving classes.

    Returns (new_timetable_df, moves, remaining_conflicts).
    Each move: dict(id, subject, class_name, conflict, reason, old, new, candidates, steps)
    """
    tt = tt.copy()
    tinfo = teacher_info(teachers_df)
    active = slots_df[slots_df["active"] == 1]
    slots = [(r["day"], int(r["period"])) for _, r in active.iterrows()]
    moves, given_up = [], set()

    for _ in range(max_moves):
        current = detect_conflicts(tt, teachers_df, rooms_df)
        pending = [c for c in current if c["message"] not in given_up]
        if not pending:
            break
        conflict = pending[0]
        # keep the first class in place, try to move the others
        movable = conflict["ids"] if len(conflict["ids"]) == 1 else conflict["ids"][1:]
        moved = False
        for eid in movable:
            idx = tt.index[tt["id"] == eid][0]
            entry = tt.loc[idx]
            best, n_candidates = _find_best_slot(entry, tt[tt["id"] != eid], tinfo, rooms_df, slots)
            if best is None:
                continue
            _, day, period, room = best
            # every rule this class was breaking (usually just one)
            reasons = [TYPE_REASON[c["type"]] for c in current if eid in c["ids"]]
            moves.append({
                "id": int(eid), "subject": entry["subject"], "class_name": entry["class_name"],
                "conflict": conflict["message"], "reason": " + ".join(dict.fromkeys(reasons)),
                "old": {"day": entry["day"], "period": int(entry["period"]), "room": entry["room"]},
                "new": {"day": day, "period": period, "room": room},
                "candidates": n_candidates,
            })
            tt.loc[idx, ["day", "period", "room"]] = [day, period, room]
            moved = True
            break
        if not moved:
            given_up.add(conflict["message"])

    remaining = detect_conflicts(tt, teachers_df, rooms_df)
    return tt, moves, remaining


def inject_demo_conflict(tt):
    """For demonstrations: move one class onto another class of the same teacher.
    Returns (entry_id, new_day, new_period, description) or None."""
    if tt.empty:
        return None
    for teacher, g in tt.groupby("teacher"):
        if len(g) < 2:
            continue
        g = g.sort_values("id")
        first = g.iloc[0]
        others = g[(g["class_name"] != first["class_name"]) & (g["room"] != first["room"])]
        if others.empty:
            continue
        victim = others.iloc[-1]
        return (int(victim["id"]), first["day"], int(first["period"]),
                f"Moved {victim['subject']} ({victim['class_name']}) onto {first['subject']} "
                f"({first['class_name']}) - both taught by {teacher} at {slot_text(first['day'], first['period'])}.")
    return None
