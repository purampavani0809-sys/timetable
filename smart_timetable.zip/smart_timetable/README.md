# 📅 AI-Based Smart Timetable and Alert System

A beginner-friendly **Streamlit** project that builds a conflict-free college timetable with
**Google OR-Tools CP-SAT**, detects conflicts, fixes them automatically and sends alerts.
Everything runs locally - no paid APIs.

## 1. Install

You need **Python 3.9 or newer**.

```bash
# (optional but recommended) create a virtual environment
python -m venv venv
venv\Scripts\activate          # Windows
source venv/bin/activate       # macOS / Linux

pip install -r requirements.txt
```

## 2. Run

```bash
streamlit run app.py
```

The browser opens automatically (usually http://localhost:8501).
The SQLite database `timetable.db` and the sample data are created on first start.

## 3. Quick demo (5 minutes)

1. **Dashboard** - see the sample data (6 teachers, 5 rooms, 12 subjects for classes CSE-A and CSE-B).
2. **Generate Timetable** - click the button. OR-Tools builds the timetable in a few seconds.
   Switch the view between Class / Teacher / Room.
3. **Conflict Detection** - click **Check Conflicts** -> "✅ No conflicts found".
4. Click **Create demo conflict** -> a conflict like
   *"Teacher Ravi is assigned to two classes at Monday Period 1"* appears.
5. Click **Auto-Resolve Conflicts** -> the class is moved, the old and new allocation are shown.
6. **Notifications** - see the "🔔 Timetable Updated" alert (Old / New / Reason).
7. **Constraints** - untick hard constraints, regenerate, and watch conflicts appear (then fix them again).

## 4. Project structure

| File | What it does |
|------|--------------|
| `app.py` | Streamlit user interface (all pages) |
| `solver.py` | OR-Tools CP-SAT model that generates the timetable |
| `conflicts.py` | Conflict detection + automatic conflict resolution |
| `notifications.py` | In-app notifications and optional SMTP e-mail |
| `database.py` | SQLite tables, helpers and auto-initialisation |
| `sample_data.py` | Sample teachers, rooms, subjects and time slots |
| `utils.py` | Small helper functions |
| `requirements.txt` | Python packages |

## 5. How the solver works

For every subject `s`, day `d`, period `p` and room `r` there is a yes/no variable
`y[s,d,p,r]` ("is subject s taught then and there?").

**Hard constraints** (must hold):
- every subject gets exactly its *classes per week*
- a teacher teaches at most one class per slot  *(checkbox)*
- a room hosts at most one class per slot  *(checkbox)*
- lab subjects use lab rooms (and theory subjects use classrooms)  *(checkbox)*
- teachers only teach in their available days/periods  *(checkbox)*
- a class never has two subjects at the same time, and the room must fit the class size *(always on)*
- a subject is spread over the week (no stacking all its classes on one day)

**Soft constraints** (penalties in the objective, followed where possible):
- avoid back-to-back classes for a teacher
- limit a teacher to N periods per day
- teachers' preferred periods give a small bonus

## 6. Conflict resolution

`conflicts.py` scans the timetable for teacher, room, class, lab-room, availability and capacity
conflicts. To fix one it tries every (day, period, room) combination, throws away options that
would break any rule, and picks the least disruptive one (same day, near the old period, preferred
period, same room). It then re-checks the whole timetable and creates a notification.

## 7. Optional e-mail notifications

Open **Notifications -> Optional e-mail notifications**, tick the box and enter your SMTP details
(for Gmail: `smtp.gmail.com`, port `587`, and an **App Password**). Or set environment variables
before starting the app: `SMTP_HOST`, `SMTP_PORT`, `SMTP_USER`, `SMTP_PASSWORD`, `NOTIFY_EMAIL_TO`.
If e-mail is off or fails, the app keeps working with in-app alerts only.

## 8. Notes and ideas for extension

- Changing subjects, teachers, rooms or slots does not change an existing timetable - press
  **Generate Timetable** again.
- Every lab session is one period long; double-period labs, student-group splits and multiple
  semesters are natural extensions.
- WhatsApp / SMS alerts (for example with Twilio) can be added later in `notifications.py`.
- To start over, use *Demo tools -> Reset sample data* in the sidebar, or delete `timetable.db`.
