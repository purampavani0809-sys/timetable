"""AI-Based Smart Timetable and Alert System  -  run with:  streamlit run app.py"""
import sqlite3
from datetime import datetime

import pandas as pd
import plotly.express as px
import streamlit as st

import database as db
import notifications as nt
import sample_data as sd
from conflicts import detect_conflicts, resolve_conflicts, inject_demo_conflict

try:
    from solver import generate_timetable
    SOLVER_ERROR = None
except ImportError as exc:                       # OR-Tools not installed
    generate_timetable = None
    SOLVER_ERROR = str(exc)

st.set_page_config(page_title="Smart Timetable", page_icon="📅", layout="wide")
db.init_db()                                     # creates timetable.db + sample data on first run

PAGES = ["📊 Dashboard", "📚 Subjects", "👩‍🏫 Teachers", "🏫 Rooms", "🕘 Time Slots",
         "⚙️ Constraints", "🧠 Generate Timetable", "🔍 Conflict Detection", "🔔 Notifications"]


# ======================================================================= helpers
def flash(kind, message):
    """Show a message after the next rerun (kind: success / warning / error / info)."""
    st.session_state["flash"] = (kind, message)


def show_flash():
    if "flash" in st.session_state:
        kind, message = st.session_state.pop("flash")
        getattr(st, kind)(message)


def version(name):
    return st.session_state.setdefault(f"ver_{name}", 0)


def bump(name):
    """Changing a data_editor key resets it, so it reloads fresh data from the database."""
    st.session_state[f"ver_{name}"] = version(name) + 1


def email_config():
    if "email_config" not in st.session_state:
        st.session_state["email_config"] = nt.email_config_from_env()
    return st.session_state["email_config"]


def sort_by_day(df):
    order = {d: i for i, d in enumerate(sd.ALL_WEEKDAYS)}
    return df.assign(_d=df["day"].map(order)).sort_values(["_d", "period"]).drop(columns="_d")


def build_grid(tt, slots_df, view_col, name):
    """Timetable grid: rows = periods, columns = days."""
    active = slots_df[slots_df["active"] == 1]
    days = list(dict.fromkeys(active["day"]))
    periods = sorted(set(int(p) for p in active["period"]))
    times = {int(r.period): f"{r.start_time}-{r.end_time}" for r in active.itertuples()}
    labels = {p: f"P{p}  ({times.get(p, '')})" for p in periods}
    grid = pd.DataFrame("", index=[labels[p] for p in periods], columns=days)

    def cell(r):
        if view_col == "class_name":
            return f"{r.subject} ({r.teacher}) [{r.room}]"
        if view_col == "teacher":
            return f"{r.subject} - {r.class_name} [{r.room}]"
        return f"{r.subject} - {r.class_name} ({r.teacher})"

    sub = tt[tt[view_col] == name]
    for (day, period), g in sub.groupby(["day", "period"]):
        if day in days and int(period) in labels:
            text = " / ".join(cell(r) for r in g.itertuples())
            grid.loc[labels[int(period)], day] = ("⚠️ " + text) if len(g) > 1 else text
    return grid


def show_timetable(tt, slots_df, key):
    if tt.empty:
        st.info("No timetable yet. Go to **Generate Timetable** and click the button.")
        return
    view = st.radio("View by", ["Class", "Teacher", "Room"], horizontal=True, key=f"{key}_view")
    col = {"Class": "class_name", "Teacher": "teacher", "Room": "room"}[view]
    name = st.selectbox(f"Select {view.lower()}", sorted(tt[col].unique()), key=f"{key}_name_{view}")
    st.dataframe(build_grid(tt, slots_df, col, name))
    with st.expander("Show full list of scheduled classes"):
        full = sort_by_day(tt).drop(columns=["id"]).rename(columns={
            "subject": "Subject", "class_name": "Class", "teacher": "Teacher", "room": "Room",
            "day": "Day", "period": "Period", "subject_type": "Type", "class_size": "Students"})
        st.dataframe(full)


# ======================================================================= pages
def page_dashboard():
    st.header("📊 Dashboard")
    subjects, teachers, rooms = db.read_df("subjects"), db.read_df("teachers"), db.read_df("rooms")
    tt = db.read_df("timetable")
    notes = db.read_df("notifications")
    conflicts = detect_conflicts(tt, teachers, rooms)
    changes = int((notes["kind"] == "moved").sum()) if not notes.empty else 0

    c1, c2, c3, c4 = st.columns(4)
    c1.metric("Total subjects", len(subjects))
    c2.metric("Total teachers", len(teachers))
    c3.metric("Total rooms", len(rooms))
    c4.metric("Scheduled classes", len(tt))
    c5, c6, c7 = st.columns(3)
    c5.metric("Conflicts right now", len(conflicts))
    c6.metric("Timetable changes", changes)
    c7.metric("Notifications", len(notes))

    if tt.empty:
        st.info("Generate a timetable to see the charts.")
        return

    left, right = st.columns(2)
    with left:
        order = [d for d in sd.ALL_WEEKDAYS if d in set(tt["day"])]
        per_day = pd.DataFrame({"Day": order, "Classes": [int((tt["day"] == d).sum()) for d in order]})
        st.plotly_chart(px.bar(per_day, x="Day", y="Classes", title="Classes per day"))
    with right:
        load = tt.groupby("teacher").size()
        work = pd.DataFrame({"Teacher": load.index, "Classes per week": load.values})
        st.plotly_chart(px.bar(work, x="Teacher", y="Classes per week", title="Teacher workload"))


def page_subjects():
    st.header("📚 Subjects")
    teachers = db.read_df("teachers")["name"].tolist()
    if not teachers:
        st.warning("Add at least one teacher first (Teachers page).")

    with st.form("add_subject", clear_on_submit=True):
        st.subheader("Add a subject")
        a, b, c = st.columns(3)
        name = a.text_input("Subject name")
        class_name = b.text_input("Class / section", value="CSE-A")
        teacher = c.selectbox("Teacher", teachers)
        d, e, f = st.columns(3)
        cpw = d.number_input("Classes per week", min_value=1, max_value=10, value=3)
        stype = e.selectbox("Type", ["Theory", "Lab"])
        size = f.number_input("Class size (students)", min_value=1, max_value=300, value=40)
        if st.form_submit_button("➕ Add subject"):
            if not name.strip() or not teacher:
                st.error("Please enter a subject name and choose a teacher.")
            else:
                db.execute("INSERT INTO subjects (name, teacher, classes_per_week, type, class_name, class_size) "
                           "VALUES (?,?,?,?,?,?)",
                           (name.strip(), teacher, int(cpw), stype, class_name.strip() or "CSE-A", int(size)))
                st.success(f"Added {name}.")

    st.subheader("All subjects (edit directly, then press Save)")
    df = db.read_df("subjects").drop(columns=["id"])
    edited = st.data_editor(
        df, num_rows="dynamic", key=f"subjects_editor_{version('subjects')}",
        column_config={
            "name": st.column_config.TextColumn("Subject", required=True),
            "teacher": st.column_config.SelectboxColumn("Teacher", options=teachers or [""], required=True),
            "classes_per_week": st.column_config.NumberColumn("Classes / week", min_value=1, max_value=10,
                                                               step=1, default=3),
            "type": st.column_config.SelectboxColumn("Type", options=["Theory", "Lab"], default="Theory"),
            "class_name": st.column_config.TextColumn("Class", default="CSE-A"),
            "class_size": st.column_config.NumberColumn("Students", min_value=1, max_value=300, step=1, default=40),
        })
    st.caption("Tip: select a row and press Delete to remove it. After changing data, regenerate the timetable.")
    if st.button("💾 Save subject changes"):
        clean = edited.dropna(subset=["name", "teacher"]).copy()
        clean = clean[clean["name"].astype(str).str.strip() != ""]
        clean["classes_per_week"] = clean["classes_per_week"].fillna(3).astype(int)
        clean["type"] = clean["type"].fillna("Theory")
        clean["class_name"] = clean["class_name"].fillna("CSE-A")
        clean["class_size"] = clean["class_size"].fillna(40).astype(int)
        db.save_table("subjects", clean)
        flash("success", "Subjects saved.")
        bump("subjects")
        st.rerun()


def page_teachers():
    st.header("👩‍🏫 Teachers")
    slots = db.read_df("timeslots")
    day_options = list(dict.fromkeys(slots["day"])) or sd.DAYS
    period_options = sorted(set(int(p) for p in slots["period"])) or list(range(1, 7))

    with st.form("add_teacher", clear_on_submit=True):
        st.subheader("Add a teacher")
        name = st.text_input("Teacher name")
        days = st.multiselect("Available days", day_options, default=day_options)
        periods = st.multiselect("Available periods", period_options, default=period_options)
        preferred = st.multiselect("Preferred periods (optional)", period_options)
        if st.form_submit_button("➕ Add teacher"):
            if not name.strip():
                st.error("Please enter a teacher name.")
            else:
                try:
                    db.execute("INSERT INTO teachers (name, available_days, available_periods, preferred_periods) "
                               "VALUES (?,?,?,?)",
                               (name.strip(), ",".join(days), ",".join(map(str, periods)),
                                ",".join(map(str, preferred))))
                    st.success(f"Added teacher {name}.")
                except sqlite3.IntegrityError:
                    st.error("A teacher with this name already exists.")

    st.subheader("All teachers (edit directly, then press Save)")
    df = db.read_df("teachers").drop(columns=["id"])
    edited = st.data_editor(
        df, num_rows="dynamic", key=f"teachers_editor_{version('teachers')}",
        column_config={
            "name": st.column_config.TextColumn("Teacher", required=True),
            "available_days": st.column_config.TextColumn("Available days (comma separated)"),
            "available_periods": st.column_config.TextColumn("Available periods (e.g. 1,2,3)"),
            "preferred_periods": st.column_config.TextColumn("Preferred periods (e.g. 1,2)"),
        })
    st.caption("Subjects refer to teachers by name, so renaming a teacher here also needs a change on the Subjects page.")
    if st.button("💾 Save teacher changes"):
        clean = edited.dropna(subset=["name"]).copy()
        clean = clean[clean["name"].astype(str).str.strip() != ""].fillna("")
        try:
            db.save_table("teachers", clean)
            flash("success", "Teachers saved.")
            bump("teachers")
            st.rerun()
        except sqlite3.IntegrityError:
            st.error("Two teachers have the same name. Names must be unique.")


def page_rooms():
    st.header("🏫 Rooms")
    with st.form("add_room", clear_on_submit=True):
        st.subheader("Add a room")
        a, b, c = st.columns(3)
        room_no = a.text_input("Room number")
        room_type = b.selectbox("Room type", ["Classroom", "Lab"])
        capacity = c.number_input("Capacity", min_value=1, max_value=500, value=60)
        if st.form_submit_button("➕ Add room"):
            if not room_no.strip():
                st.error("Please enter a room number.")
            else:
                try:
                    db.execute("INSERT INTO rooms (room_no, room_type, capacity) VALUES (?,?,?)",
                               (room_no.strip(), room_type, int(capacity)))
                    st.success(f"Added room {room_no}.")
                except sqlite3.IntegrityError:
                    st.error("This room number already exists.")

    st.subheader("All rooms (edit directly, then press Save)")
    df = db.read_df("rooms").drop(columns=["id"])
    edited = st.data_editor(
        df, num_rows="dynamic", key=f"rooms_editor_{version('rooms')}",
        column_config={
            "room_no": st.column_config.TextColumn("Room number", required=True),
            "room_type": st.column_config.SelectboxColumn("Type", options=["Classroom", "Lab"], default="Classroom"),
            "capacity": st.column_config.NumberColumn("Capacity", min_value=1, max_value=500, step=1, default=60),
        })
    if st.button("💾 Save room changes"):
        clean = edited.dropna(subset=["room_no"]).copy()
        clean = clean[clean["room_no"].astype(str).str.strip() != ""]
        clean["room_type"] = clean["room_type"].fillna("Classroom")
        clean["capacity"] = clean["capacity"].fillna(60).astype(int)
        try:
            db.save_table("rooms", clean)
            flash("success", "Rooms saved.")
            bump("rooms")
            st.rerun()
        except sqlite3.IntegrityError:
            st.error("Two rooms have the same number. Room numbers must be unique.")


def page_timeslots():
    st.header("🕘 Time Slots")
    slots = db.read_df("timeslots")
    current_days = list(dict.fromkeys(slots["day"])) or sd.DAYS
    current_periods = int(slots["period"].max()) if not slots.empty else sd.PERIODS_PER_DAY

    st.subheader("Quick setup")
    a, b, c, d = st.columns(4)
    days = a.multiselect("Working days", sd.ALL_WEEKDAYS, default=current_days)
    periods = b.number_input("Periods per day", min_value=1, max_value=10, value=current_periods)
    start = c.text_input("First period starts at (HH:MM)", value="09:00")
    length = d.number_input("Period length (minutes)", min_value=20, max_value=120, value=50)
    col1, col2 = st.columns(2)
    if col1.button("🔄 Rebuild time slots"):
        try:
            datetime.strptime(start, "%H:%M")
        except ValueError:
            st.error("Start time must look like 09:00")
        else:
            if not days:
                st.error("Choose at least one working day.")
            else:
                db.reset_timeslots(db.default_timeslots(days, int(periods), start, int(length)))
                flash("success", "Time slots rebuilt. Please regenerate the timetable.")
                bump("slots")
                st.rerun()
    if col2.button("↩️ Reset to default (Mon-Fri, 6 periods)"):
        db.reset_timeslots()
        flash("success", "Default time slots restored.")
        bump("slots")
        st.rerun()

    st.subheader("Fine-tune individual slots")
    df = slots.drop(columns=["id"]).copy()
    df["active"] = df["active"].astype(bool)
    edited = st.data_editor(
        df, num_rows="dynamic", key=f"slots_editor_{version('slots')}",
        column_config={
            "day": st.column_config.SelectboxColumn("Day", options=sd.ALL_WEEKDAYS, required=True),
            "period": st.column_config.NumberColumn("Period", min_value=1, max_value=10, step=1, required=True),
            "start_time": st.column_config.TextColumn("Start"),
            "end_time": st.column_config.TextColumn("End"),
            "active": st.column_config.CheckboxColumn("Use this slot", default=True),
        })
    st.caption("Untick 'Use this slot' to block a period (for example a lunch break or a holiday).")
    if st.button("💾 Save time slot changes"):
        clean = edited.dropna(subset=["day", "period"]).copy()
        clean["period"] = clean["period"].astype(int)
        clean["active"] = clean["active"].fillna(True).astype(int)
        clean = clean.fillna("")
        db.save_table("timeslots", clean)
        flash("success", "Time slots saved.")
        bump("slots")
        st.rerun()


def page_constraints():
    st.header("⚙️ Constraints and Preferences")
    s = db.get_settings()

    st.subheader("Hard constraints (must be satisfied)")
    s["prevent_teacher_clash"] = st.checkbox("Prevent teacher double booking", value=s["prevent_teacher_clash"])
    s["prevent_room_clash"] = st.checkbox("Prevent room double booking", value=s["prevent_room_clash"])
    s["require_lab_room"] = st.checkbox("Require lab room for lab subjects", value=s["require_lab_room"])
    s["respect_availability"] = st.checkbox("Respect teacher availability", value=s["respect_availability"])

    st.subheader("Soft constraints (preferences, followed where possible)")
    s["avoid_back_to_back"] = st.checkbox("Avoid back-to-back classes for teachers", value=s["avoid_back_to_back"])
    s["limit_workload"] = st.checkbox("Limit teacher workload", value=s["limit_workload"])
    s["max_periods_per_day"] = st.number_input("Maximum periods per teacher per day", min_value=1, max_value=10,
                                               value=int(s["max_periods_per_day"]))
    if st.button("💾 Save constraints"):
        db.save_settings(s)
        st.success("Constraints saved. They are used the next time you generate a timetable.")

    st.info("Always enforced: a class can't have two subjects at the same time, rooms must be big enough, "
            "and each subject has at most a fair share of its classes on one day. "
            "Teacher preferred periods are used as a small bonus.")
    st.caption("Switching off a hard constraint is useful for demos: the solver may then create conflicts "
               "that you can detect and fix on the Conflict Detection page.")


def page_generate():
    st.header("🧠 Generate Timetable")
    if generate_timetable is None:
        st.error("OR-Tools is not installed. Run:  pip install -r requirements.txt")
        st.code(SOLVER_ERROR)
        return
    settings = db.get_settings()
    with st.expander("Constraints that will be used"):
        hard = {"Prevent teacher double booking": "prevent_teacher_clash",
                "Prevent room double booking": "prevent_room_clash",
                "Require lab room for lab subjects": "require_lab_room",
                "Respect teacher availability": "respect_availability"}
        soft = {"Avoid back-to-back classes": "avoid_back_to_back", "Limit teacher workload": "limit_workload"}
        st.write("**Hard:** " + ", ".join(f"{'✅' if settings[k] else '❌'} {n}" for n, k in hard.items()))
        st.write("**Soft:** " + ", ".join(f"{'✅' if settings[k] else '❌'} {n}" for n, k in soft.items())
                 + f"  (max {settings['max_periods_per_day']} periods/day)")

    time_limit = st.number_input("Solver time limit (seconds)", min_value=5, max_value=120, value=20)
    if st.button("⚙️ Generate Timetable", type="primary"):
        with st.spinner("OR-Tools CP-SAT is building your timetable..."):
            ok, rows, messages = generate_timetable(
                db.read_df("subjects"), db.read_df("teachers"), db.read_df("rooms"),
                db.read_df("timeslots"), settings, time_limit=time_limit)
        if ok:
            db.replace_timetable(rows)
            info = nt.notify_generated(len(rows), email_config())
            st.success(f"✅ {messages[0]}")
            if info:
                st.caption(info)
            found = detect_conflicts(db.read_df("timetable"), db.read_df("teachers"), db.read_df("rooms"))
            if found:
                st.warning(f"⚠️ {len(found)} conflict(s) exist because some hard constraints are switched off. "
                           "See the Conflict Detection page.")
        else:
            st.error("Could not generate a timetable.")
            for m in messages:
                st.warning(m)

    st.subheader("Current timetable")
    show_timetable(db.read_df("timetable"), db.read_df("timeslots"), key="gen")


def page_conflicts():
    st.header("🔍 Conflict Detection and Resolution")
    teachers, rooms, slots = db.read_df("teachers"), db.read_df("rooms"), db.read_df("timeslots")

    b1, b2, b3 = st.columns(3)
    if b1.button("🔍 Check Conflicts"):
        st.session_state["checked"] = True
        st.session_state.pop("resolve_result", None)
    if b2.button("🛠️ Auto-Resolve Conflicts"):
        st.session_state["checked"] = True
        tt = db.read_df("timetable")
        if tt.empty:
            st.warning("Generate a timetable first.")
        else:
            _, moves, remaining = resolve_conflicts(tt, teachers, rooms, slots)
            email_notes = []
            for m in moves:
                db.update_timetable_entry(m["id"], m["new"]["room"], m["new"]["day"], m["new"]["period"])
                info = nt.notify_move(m, email_config())
                if info:
                    email_notes.append(info)
            st.session_state["resolve_result"] = {
                "moves": moves, "remaining": [c["message"] for c in remaining], "email": email_notes}
    if b3.button("🧪 Create demo conflict"):
        st.session_state["checked"] = True
        st.session_state.pop("resolve_result", None)
        result = inject_demo_conflict(db.read_df("timetable"))
        if result is None:
            st.warning("Generate a timetable first (it needs a teacher with two classes).")
        else:
            entry_id, day, period, text = result
            tt = db.read_df("timetable")
            room = tt.loc[tt["id"] == entry_id, "room"].iloc[0]
            db.update_timetable_entry(entry_id, room, day, period)
            st.info("Demo conflict created: " + text)

    if not st.session_state.get("checked"):
        st.info("Click **Check Conflicts** to scan the timetable. Use **Create demo conflict** to see how "
                "automatic resolution works.")
        return

    tt = db.read_df("timetable")
    if tt.empty:
        st.info("No timetable yet. Generate one first.")
        return

    result = st.session_state.get("resolve_result")
    if result:
        show_resolution(result)

    conflicts = detect_conflicts(tt, teachers, rooms)
    st.subheader("Conflict check")
    if not conflicts:
        st.success("✅ No conflicts found")
    else:
        for c in conflicts:
            st.warning("⚠️ Conflict Found\n\n" + c["message"])
        st.caption("Click **Auto-Resolve Conflicts** to let the system move the affected classes.")

    st.subheader("Timetable")
    show_timetable(tt, slots, key="conf")


def show_resolution(result):
    st.subheader("Automatic conflict resolution")
    moves = result["moves"]
    if not moves and not result["remaining"]:
        st.success("✅ No conflicts found, nothing to resolve.")
    for m in moves:
        st.write(f"**{m['subject']} ({m['class_name']})** - {m['conflict']}")
        st.code(
            "Conflict detected\n"
            "       ↓\n"
            f"Find available slots   ({m['candidates']} options found)\n"
            "       ↓\n"
            "Check constraints      (teacher, room, class, lab room, availability)\n"
            "       ↓\n"
            "Move class\n"
            "       ↓\n"
            "Verify timetable\n"
            "       ↓\n"
            "Conflict resolved", language="text")
    if moves:
        table = pd.DataFrame([{
            "Subject": f"{m['subject']} ({m['class_name']})",
            "Old allocation": f"{m['old']['day']} - Period {m['old']['period']} - Room {m['old']['room']}",
            "New allocation": f"{m['new']['day']} - Period {m['new']['period']} - Room {m['new']['room']}",
            "Reason": m["reason"]} for m in moves])
        st.dataframe(table)
    if result["remaining"]:
        st.error("Some conflicts could not be resolved automatically (no free slot found):")
        for msg in result["remaining"]:
            st.warning(msg)
    elif moves:
        st.success("✅ Timetable verified - all conflicts resolved. Notifications were created.")
    for note in result["email"]:
        st.caption(note)


def page_notifications():
    st.header("🔔 Notifications")
    notes = db.read_df("notifications")
    if notes.empty:
        st.info("No notifications yet. They appear when a timetable is generated or a class is moved.")
    else:
        for n in notes.sort_values("id", ascending=False).to_dict("records"):
            text = nt.notification_text(n).replace("\n", "  \n")
            (st.success if n["kind"] == "generated" else st.info)(f"{text}\n\n*{n['created_at']}*")
        if st.button("🗑️ Clear all notifications"):
            db.execute("DELETE FROM notifications")
            st.rerun()

    st.divider()
    with st.expander("📧 Optional e-mail notifications (SMTP)"):
        st.caption("Leave this switched off and the app still works. For Gmail use an App Password, not your "
                   "normal password. Settings are kept only while the app is running.")
        cfg = email_config()
        enabled = st.checkbox("Send e-mails when the timetable changes", value=cfg["enabled"])
        host = st.text_input("SMTP host", value=cfg["host"])
        port = st.number_input("SMTP port", min_value=1, max_value=65535, value=int(cfg["port"]))
        user = st.text_input("SMTP username (your e-mail)", value=cfg["user"])
        password = st.text_input("SMTP password / app password", value=cfg["password"], type="password")
        to = st.text_input("Send notifications to", value=cfg["to"])
        c1, c2 = st.columns(2)
        if c1.button("Save e-mail settings"):
            st.session_state["email_config"] = {"enabled": enabled, "host": host, "port": int(port),
                                                "user": user, "password": password, "to": to}
            st.success("E-mail settings saved for this session.")
        if c2.button("Send test e-mail"):
            test = {"enabled": True, "host": host, "port": int(port), "user": user, "password": password, "to": to}
            ok, info = nt.send_email(test, "Smart Timetable test", "This is a test e-mail from the timetable app.")
            (st.success if ok else st.error)(info)
    st.caption("WhatsApp / SMS alerts are not part of the basic version (possible future extension).")


# ======================================================================= main
st.sidebar.title("📅 Smart Timetable")
st.sidebar.caption("AI-Based Smart Timetable and Alert System")
page = st.sidebar.radio("Menu", PAGES)
with st.sidebar.expander("Demo tools"):
    confirm = st.checkbox("I want to erase everything and reload the sample data")
    if st.button("Reset sample data") and confirm:
        db.reset_sample_data()
        flash("success", "Sample data restored.")
        st.rerun()

show_flash()
if page == PAGES[0]:
    page_dashboard()
elif page == PAGES[1]:
    page_subjects()
elif page == PAGES[2]:
    page_teachers()
elif page == PAGES[3]:
    page_rooms()
elif page == PAGES[4]:
    page_timeslots()
elif page == PAGES[5]:
    page_constraints()
elif page == PAGES[6]:
    page_generate()
elif page == PAGES[7]:
    page_conflicts()
else:
    page_notifications()
