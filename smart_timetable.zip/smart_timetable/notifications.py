"""In-app notifications (stored in SQLite) + OPTIONAL e-mail through SMTP.

E-mail is only sent when the admin turns it on and fills in the SMTP details
(on the Notifications page, or with the environment variables below).
Without them the app works normally and just shows in-app alerts.
"""
import os
import smtplib
from datetime import datetime
from email.message import EmailMessage

import database as db
from utils import slot_text


def email_config_from_env():
    return {
        "enabled": False,
        "host": os.environ.get("SMTP_HOST", "smtp.gmail.com"),
        "port": int(os.environ.get("SMTP_PORT", "587")),
        "user": os.environ.get("SMTP_USER", ""),
        "password": os.environ.get("SMTP_PASSWORD", ""),
        "to": os.environ.get("NOTIFY_EMAIL_TO", ""),
    }


def send_email(config, subject, body):
    """Send one e-mail. Returns (ok, message). Never raises, so the app keeps working."""
    if not config or not config.get("enabled"):
        return False, "E-mail notifications are switched off."
    if not (config.get("host") and config.get("user") and config.get("password") and config.get("to")):
        return False, "E-mail settings are incomplete."
    try:
        msg = EmailMessage()
        msg["Subject"] = subject
        msg["From"] = config["user"]
        msg["To"] = config["to"]
        msg.set_content(body)
        with smtplib.SMTP(config["host"], int(config["port"]), timeout=10) as server:
            server.starttls()
            server.login(config["user"], config["password"])
            server.send_message(msg)
        return True, f"E-mail sent to {config['to']}."
    except Exception as exc:                      # wrong password, no internet, ...
        return False, f"E-mail could not be sent: {exc}"


def add_notification(kind, subject, old_slot, new_slot, reason, emailed=0):
    return db.execute(
        "INSERT INTO notifications (created_at, kind, subject, old_slot, new_slot, reason, emailed) "
        "VALUES (?,?,?,?,?,?,?)",
        (datetime.now().strftime("%Y-%m-%d %H:%M:%S"), kind, subject, old_slot, new_slot, reason, emailed))


def notification_text(n):
    """The text shown in the app (and e-mailed)."""
    if n["kind"] == "generated":
        return f"🆕 Timetable Generated\n\n{n['reason']}"
    return (f"🔔 Timetable Updated\n\n{n['subject']}\n"
            f"Old: {n['old_slot']}\nNew: {n['new_slot']}\n\nReason: {n['reason']}")


def notify_move(move, email_config=None):
    """Store an in-app alert for one moved class and (optionally) e-mail it.
    Returns a short status message about the e-mail (or None)."""
    subject = f"{move['subject']} ({move['class_name']})"
    old = slot_text(move["old"]["day"], move["old"]["period"]) + f" (Room {move['old']['room']})"
    new = slot_text(move["new"]["day"], move["new"]["period"]) + f" (Room {move['new']['room']})"
    row = {"kind": "moved", "subject": subject, "old_slot": old, "new_slot": new, "reason": move["reason"]}
    ok, info = send_email(email_config, f"Timetable Updated: {subject}", notification_text(row))
    add_notification("moved", subject, old, new, move["reason"], int(ok))
    return info if (email_config or {}).get("enabled") else None


def notify_generated(count, email_config=None):
    reason = f"A new conflict-free timetable with {count} classes was generated."
    row = {"kind": "generated", "reason": reason}
    ok, info = send_email(email_config, "New Timetable Generated", notification_text(row))
    add_notification("generated", "All subjects", "", "", reason, int(ok))
    return info if (email_config or {}).get("enabled") else None
